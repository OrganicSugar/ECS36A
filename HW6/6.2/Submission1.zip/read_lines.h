#ifndef READ_LINES_H
  #define READ_LINES_H

  FILE* validate_input(int argc, char* argv[]);
  void read_lines(FILE* fp, char*** lines, int* num_lines);
  void print_lines(char** lines, int num_lines);
  void free_lines(char** lines, int num_lines);

#endif
