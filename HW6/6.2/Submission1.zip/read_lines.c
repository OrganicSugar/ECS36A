#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "read_lines.h"


void read_lines(FILE* fp, char*** lines, int* num_lines) {
  char c;
  bool allocNewLine = false;
  int characters = 0;
  *num_lines = 0;
  fscanf(fp, "%c", &c);
  if (c == '\0') {
    return;
  } else {
    characters++;
  }
  (*num_lines)++;
  *lines = (char**)malloc(sizeof(char**));
  *lines[(*num_lines) - 1] = (char*)malloc(sizeof(char));
  while(!feof(fp)) {
    if (allocNewLine) {
      (*num_lines)++;
      *lines = realloc(*lines, sizeof(char*) * (*num_lines));
      characters = 0;
      allocNewLine = false;
      (*lines)[(*num_lines) - 1] = calloc(characters, sizeof(char));
    }
    if (c == '\n') {
      allocNewLine = true;
    }
    (*lines)[(*num_lines) - 1] = realloc(*lines[(*num_lines) - 1], sizeof(char) * characters);
    (*lines)[(*num_lines) - 1][characters] = c;
    characters++;
    fscanf(fp, "%c", &c);
  }
}
